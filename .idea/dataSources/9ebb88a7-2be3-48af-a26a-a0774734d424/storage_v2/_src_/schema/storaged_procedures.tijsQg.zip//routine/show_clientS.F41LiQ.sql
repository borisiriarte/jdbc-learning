create
    definer = root@localhost procedure show_clientS()
BEGIN
    SELECT * FROM clients WHERE town = 'Cali';
END;

