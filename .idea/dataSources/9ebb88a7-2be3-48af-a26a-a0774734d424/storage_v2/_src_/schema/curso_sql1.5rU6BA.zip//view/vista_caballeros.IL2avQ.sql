create definer = root@localhost view vista_caballeros as
select `c`.`caballero_id` AS `caballero_id`,
       `c`.`nombre`       AS `nombre`,
       `a`.`armadura`     AS `armadura`,
       `s`.`signo`        AS `signo`,
       `r`.`rango`        AS `rango`,
       `e`.`ejercito`     AS `ejercito`,
       `p`.`pais`         AS `pais`
from (((((`curso_sql1`.`caballeros` `c` join `curso_sql1`.`armaduras` `a`
          on ((`c`.`armadura` = `a`.`armadura_id`))) join `curso_sql1`.`signos` `s`
         on ((`c`.`signo` = `s`.`signo_id`))) join `curso_sql1`.`rangos` `r`
        on ((`c`.`rango` = `r`.`rango_id`))) join `curso_sql1`.`ejercitos` `e`
       on ((`c`.`ejercito` = `e`.`ejercito_id`))) join `curso_sql1`.`paises` `p` on ((`c`.`pais` = `p`.`pais_id`)));

