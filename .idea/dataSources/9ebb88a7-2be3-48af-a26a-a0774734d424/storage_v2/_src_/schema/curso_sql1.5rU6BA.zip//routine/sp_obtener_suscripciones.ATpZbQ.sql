create
    definer = root@localhost procedure sp_obtener_suscripciones()
BEGIN
        SELECT * FROM suscripciones;  
    END;

