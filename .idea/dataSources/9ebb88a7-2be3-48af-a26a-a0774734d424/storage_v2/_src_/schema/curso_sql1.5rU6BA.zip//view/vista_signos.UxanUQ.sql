create definer = root@localhost view vista_signos as
select `s`.`signo`                                                                               AS `signo`,
       (select count(0) from `curso_sql1`.`caballeros` `c` where (`c`.`signo` = `s`.`signo_id`)) AS `total_caballeros`
from `curso_sql1`.`signos` `s`;

