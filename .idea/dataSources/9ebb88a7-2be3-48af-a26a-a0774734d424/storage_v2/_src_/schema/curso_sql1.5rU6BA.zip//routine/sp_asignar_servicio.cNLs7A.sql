create
    definer = root@localhost procedure sp_asignar_servicio(IN i_suscripcion int unsigned, IN i_nombre varchar(30),
                                                           IN i_correo varchar(50), IN i_tarjeta varchar(50),
                                                           OUT o_respuesta varchar(50))
BEGIN
        
        DECLARE existe_correo INT DEFAULT 0;
        DECLARE cliente_id INT DEFAULT 0;
        DECLARE tarjeta_id INT DEFAULT 0;
        
        START TRANSACTION;
    
            SELECT COUNT(*) INTO existe_correo
                FROM clientes
                WHERE correo = i_correo;
            
            IF existe_correo <> 0 THEN
                SELECT 'Tu correo ya ha sido registrado' INTO o_respuesta;
            
            ELSE
                INSERT INTO clientes VALUES(0, i_nombre, i_correo);
                SELECT LAST_INSERT_ID() INTO cliente_id;
            
                INSERT INTO tarjetas
                    VALUES(0, cliente_id, AES_ENCRYPT(i_tarjeta, cliente_id));
                SELECT LAST_INSERT_ID() INTO tarjeta_id;
            
                INSERT INTO servicios VALUES(0, cliente_id, tarjeta_id, i_suscripcion);
            
                SELECT 'Servicio asignado con exito' INTO o_respuesta;
            END IF;
            
        COMMIT;
    END;

