create definer = root@localhost trigger tg_actividad_clientes
    after insert
    on clientes
    for each row
BEGIN
        
        INSERT INTO actividad_clientes VALUES(0, NEW.cliente_id, NOW());
        
    END;

