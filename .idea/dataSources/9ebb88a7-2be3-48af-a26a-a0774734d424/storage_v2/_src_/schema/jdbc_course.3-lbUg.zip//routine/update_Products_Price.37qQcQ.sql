create
    definer = root@localhost procedure update_Products_Price(IN price_art int, IN art_name varchar(50))
BEGIN
        UPDATE products_table SET price = price_art WHERE name = art_name;
    END;

